from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import get_user_model
from django.forms import ValidationError
from django.conf import settings
from captcha.fields import CaptchaField



recaptcha = forms.CharField(widget=forms.HiddenInput())
class CaptchaTestForm(forms.Form):
    captcha = CaptchaField()
    class Meta:
        model = MyModel