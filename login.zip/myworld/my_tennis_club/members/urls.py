from django.urls import path
from . import views

"""urlpatterns = [
    path('members/', views.members, name='members'),
]"""

app_name='members'
urlpatterns = [
    path('inicio/', views.home, name='home'),
]