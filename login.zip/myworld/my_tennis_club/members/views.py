from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from django.contrib.auth.decorators import login_required

def members(request):
  template = loader.get_template('myfirst.html')
  return HttpResponse(template.render())

@login_required
def home(request):
  return HttpResponse("Hola a todos")